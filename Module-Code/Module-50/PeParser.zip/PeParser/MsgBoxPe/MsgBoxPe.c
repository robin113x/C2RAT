#include <Windows.h>
#include <stdio.h>






int main() {

	MessageBox(NULL, L"This Is A Test Pe", L"MaldevAcademy", MB_OK | MB_ICONINFORMATION);
	return 0;
}




