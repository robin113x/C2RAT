#pragma once

#include <Windows.h>


#ifndef STRUCTS_H
#define STRUCTS_H



typedef struct _UNICODE_STRING {
	USHORT Length;
	USHORT MaximumLength;
	PWSTR  Buffer;
} UNICODE_STRING, * PUNICODE_STRING;


typedef struct _OBJECT_ATTRIBUTES {
	ULONG           Length;
	HANDLE          RootDirectory;
	PUNICODE_STRING ObjectName;
	ULONG           Attributes;
	PVOID           SecurityDescriptor;
	PVOID           SecurityQualityOfService;
} OBJECT_ATTRIBUTES, *POBJECT_ATTRIBUTES;


typedef enum _SECTION_INHERIT {
	ViewShare = 1,
	ViewUnmap = 2
} SECTION_INHERIT, * PSECTION_INHERIT;


typedef struct _PS_ATTRIBUTE
{
	ULONG  Attribute;
	SIZE_T Size;
	union
	{
		ULONG Value;
		PVOID ValuePtr;
	} u1;
	PSIZE_T ReturnLength;
} PS_ATTRIBUTE, * PPS_ATTRIBUTE;


typedef struct _PS_ATTRIBUTE_LIST
{
	SIZE_T       TotalLength;
	PS_ATTRIBUTE Attributes[1];
} PS_ATTRIBUTE_LIST, * PPS_ATTRIBUTE_LIST;


// https://learn.microsoft.com/en-us/windows-hardware/drivers/ddi/ntifs/nf-ntifs-ntcreatesection
typedef NTSTATUS(NTAPI* fnNtCreateSection)(
	PHANDLE				SectionHandle,
	ACCESS_MASK			DesiredAccess,
	POBJECT_ATTRIBUTES	ObjectAttributes,
	PLARGE_INTEGER		MaximumSize,
	ULONG				SectionPageProtection,
	ULONG				AllocationAttributes,
	HANDLE				FileHandle
	);

// http://undocumented.ntinternals.net/UserMode/Undocumented%20Functions/NT%20Objects/Section/NtMapViewOfSection.html
typedef NTSTATUS(NTAPI* fnNtMapViewOfSection)(
	HANDLE				SectionHandle,
	HANDLE				ProcessHandle,
	PVOID* BaseAddress,
	ULONG_PTR			ZeroBits,
	SIZE_T				CommitSize,
	PLARGE_INTEGER		SectionOffset,
	PSIZE_T				ViewSize,
	SECTION_INHERIT		InheritDisposition,
	ULONG				AllocationType,
	ULONG				Win32Protect
	);

// http://undocumented.ntinternals.net/UserMode/Undocumented%20Functions/NT%20Objects/Section/NtUnmapViewOfSection.html
typedef NTSTATUS(NTAPI* fnUnmapViewOfSection)(
	HANDLE				ProcessHandle,
	PVOID				BaseAddress
	);

// http://undocumented.ntinternals.net/UserMode/Undocumented%20Functions/NT%20Objects/Type%20independed/NtClose.html
typedef NTSTATUS(NTAPI* fnNtClose)(
	HANDLE				Handle
	);


// // https://github.com/winsiderss/systeminformer/blob/master/phnt/include/ntpsapi.h#L2228
typedef NTSTATUS(NTAPI* fnNtCreateThreadEx)(
	PHANDLE ThreadHandle,
	ACCESS_MASK DesiredAccess,
	POBJECT_ATTRIBUTES ObjectAttributes,
	HANDLE ProcessHandle,
	PVOID StartRoutine,
	PVOID Argument,
	ULONG CreateFlags,
	SIZE_T ZeroBits,
	SIZE_T StackSize,
	SIZE_T MaximumStackSize,
	PPS_ATTRIBUTE_LIST AttributeList
	);


#endif // !STRUCTS_H






